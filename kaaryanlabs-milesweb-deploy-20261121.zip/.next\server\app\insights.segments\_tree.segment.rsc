:HL["/_next/static/chunks/3k05luupwfi75.css","style"]
:HL["/_next/static/media/Geist_Variable-s.p.3h407z6i7-mwk.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"insights","h":96,"c":"$Q2"}]]
0:{"b":"ZU9tStWw0IuRMcwMXEGA6","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
