module.exports=[38037,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_our-process_page_actions_1fhzoogxprwao.js.map