var R=require("../../chunks/[turbopack]_runtime.js")("server/app/opengraph-image/route.js")
R.c("server/chunks/[externals]__07pdjks4yh9sk._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_06mt9xc47tthe._.js")
R.c("server/chunks/_next-internal_server_app_opengraph-image_route_actions_1n32_cshpygg5.js")
R.m(9191)
module.exports=R.m(9191).exports
