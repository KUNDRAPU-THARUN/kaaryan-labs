:HL["/_next/static/css/de381b2657310ee3.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"our-story","h":96,"c":"$Q2"}]]
0:{"b":"SbTi7u24UdGEVMWExOFuZ","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
