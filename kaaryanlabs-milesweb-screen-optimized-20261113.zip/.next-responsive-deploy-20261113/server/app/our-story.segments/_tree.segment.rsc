:HL["/_next/static/css/c333ba62a30ea794.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"our-story","h":96,"c":"$Q2"}]]
0:{"b":"E7ETJ7tMB36HwhE2IjOfn","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
