:HL["/_next/static/chunks/0u_c-uvoe0xhg.css","style"]
:HL["/_next/static/media/Geist_Variable-s.p.3h407z6i7-mwk.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":{"n":"slug","t":"d","k":"lean-mvp-blueprint-validating-startup-ideas","s":[]},"h":96,"c":"$Q3"}]]
1:[["children",{"s":"insights","h":96,"c":"$Q2"}]]
0:{"b":"VztSY1JnkJ3O4cv7vA3EU","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
