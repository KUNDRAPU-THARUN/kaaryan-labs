module.exports=[88783,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_about-us_page_actions_0st9uzmjcu5vn.js.map