module.exports=[18359,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_our-story_page_actions_00xhzal8120ma.js.map