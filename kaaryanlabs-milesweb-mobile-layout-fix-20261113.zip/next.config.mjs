/** @type {import('next').NextConfig} */
const nextConfig = {
  devIndicators: false,
  distDir: '.next-responsive-deploy-20261113',
  experimental: { cpus: 1 },
  images: { qualities: [75, 90, 100] },
};

export default nextConfig;