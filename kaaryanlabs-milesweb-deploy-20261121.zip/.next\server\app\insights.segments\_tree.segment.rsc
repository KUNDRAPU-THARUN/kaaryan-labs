:HL["/_next/static/chunks/2ll407bl7w8pe.css","style"]
:HL["/_next/static/media/Geist_Variable-s.p.3h407z6i7-mwk.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"insights","h":96,"c":"$Q2"}]]
0:{"b":"yGkcmh8El0QmULflwbW3K","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
