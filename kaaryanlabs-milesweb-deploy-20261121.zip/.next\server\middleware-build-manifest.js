globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/AM-tMq1kNdHBnVOX1AB62/_buildManifest.js",
    "static/AM-tMq1kNdHBnVOX1AB62/_ssgManifest.js",
    "static/AM-tMq1kNdHBnVOX1AB62/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1pcw6gskne7pf.js",
    "static/chunks/1d-3ziz_810o8.js",
    "static/chunks/04cc_heshj4gz.js",
    "static/chunks/0gy1dczh8t-w0.js",
    "static/chunks/turbopack-077hmtqrhcoji.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1d-3ziz_810o8.js",
        "static/chunks/04cc_heshj4gz.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1d-3ziz_810o8.js",
        "static/chunks/04cc_heshj4gz.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1d-3ziz_810o8.js",
        "static/chunks/04cc_heshj4gz.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/about-us/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1d-3ziz_810o8.js",
        "static/chunks/04cc_heshj4gz.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/contact/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1d-3ziz_810o8.js",
        "static/chunks/04cc_heshj4gz.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/contact-us/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1d-3ziz_810o8.js",
        "static/chunks/04cc_heshj4gz.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/insights/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1d-3ziz_810o8.js",
        "static/chunks/04cc_heshj4gz.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/insights/[slug]/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1d-3ziz_810o8.js",
        "static/chunks/04cc_heshj4gz.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/our-process/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1d-3ziz_810o8.js",
        "static/chunks/04cc_heshj4gz.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/our-story/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1d-3ziz_810o8.js",
        "static/chunks/04cc_heshj4gz.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/services/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1d-3ziz_810o8.js",
        "static/chunks/04cc_heshj4gz.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/startup-support/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1d-3ziz_810o8.js",
        "static/chunks/04cc_heshj4gz.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
