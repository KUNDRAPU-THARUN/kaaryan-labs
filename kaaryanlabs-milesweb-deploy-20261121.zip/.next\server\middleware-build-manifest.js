globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/uRjoir-SM-YGTG2Lu1DCk/_buildManifest.js",
    "static/uRjoir-SM-YGTG2Lu1DCk/_ssgManifest.js",
    "static/uRjoir-SM-YGTG2Lu1DCk/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0y3v_gwlex4io.js",
    "static/chunks/24pmacv9f6q9n.js",
    "static/chunks/04cc_heshj4gz.js",
    "static/chunks/turbopack-077hmtqrhcoji.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/0y3v_gwlex4io.js",
        "static/chunks/24pmacv9f6q9n.js",
        "static/chunks/04cc_heshj4gz.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/0y3v_gwlex4io.js",
        "static/chunks/24pmacv9f6q9n.js",
        "static/chunks/04cc_heshj4gz.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/0y3v_gwlex4io.js",
        "static/chunks/24pmacv9f6q9n.js",
        "static/chunks/04cc_heshj4gz.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/about-us/page": {
      "otherChunks": [
        "static/chunks/0y3v_gwlex4io.js",
        "static/chunks/24pmacv9f6q9n.js",
        "static/chunks/04cc_heshj4gz.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/contact/page": {
      "otherChunks": [
        "static/chunks/0y3v_gwlex4io.js",
        "static/chunks/24pmacv9f6q9n.js",
        "static/chunks/04cc_heshj4gz.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/contact-us/page": {
      "otherChunks": [
        "static/chunks/0y3v_gwlex4io.js",
        "static/chunks/24pmacv9f6q9n.js",
        "static/chunks/04cc_heshj4gz.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/insights/page": {
      "otherChunks": [
        "static/chunks/0y3v_gwlex4io.js",
        "static/chunks/24pmacv9f6q9n.js",
        "static/chunks/04cc_heshj4gz.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/insights/[slug]/page": {
      "otherChunks": [
        "static/chunks/0y3v_gwlex4io.js",
        "static/chunks/24pmacv9f6q9n.js",
        "static/chunks/04cc_heshj4gz.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/our-process/page": {
      "otherChunks": [
        "static/chunks/0y3v_gwlex4io.js",
        "static/chunks/24pmacv9f6q9n.js",
        "static/chunks/04cc_heshj4gz.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/our-story/page": {
      "otherChunks": [
        "static/chunks/0y3v_gwlex4io.js",
        "static/chunks/24pmacv9f6q9n.js",
        "static/chunks/04cc_heshj4gz.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/services/page": {
      "otherChunks": [
        "static/chunks/0y3v_gwlex4io.js",
        "static/chunks/24pmacv9f6q9n.js",
        "static/chunks/04cc_heshj4gz.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/startup-support/page": {
      "otherChunks": [
        "static/chunks/0y3v_gwlex4io.js",
        "static/chunks/24pmacv9f6q9n.js",
        "static/chunks/04cc_heshj4gz.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
