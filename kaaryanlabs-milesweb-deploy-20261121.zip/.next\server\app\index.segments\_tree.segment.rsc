:HL["/_next/static/chunks/1cwljpdc_76zs.css","style"]
:HL["/_next/static/media/Geist_Variable-s.p.3h407z6i7-mwk.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
1:[["children",{"s":"__PAGE__","h":160}]]
0:{"b":"AM-tMq1kNdHBnVOX1AB62","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
