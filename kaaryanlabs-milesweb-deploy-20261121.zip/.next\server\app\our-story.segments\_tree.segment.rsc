:HL["/_next/static/chunks/0i5716jlfp3uy.css","style"]
:HL["/_next/static/media/Geist_Variable-s.p.3h407z6i7-mwk.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"our-story","h":96,"c":"$Q2"}]]
0:{"b":"3fVnFEkHQ9I3NiSCzirke","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
